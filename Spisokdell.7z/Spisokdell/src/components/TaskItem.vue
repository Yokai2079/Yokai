<template>
  <div class="task-card" :class="cardClasses">
    <div class="task-card__header">
      <div class="task-meta">
        <span class="task-category">{{ task.category }}</span>
        <span class="task-priority" :class="priorityClass">{{ priorityText }}</span>
      </div>
      <div class="task-actions">
        <button 
          class="task-checkbox" 
          :class="{ 'task-checkbox--completed': task.completed }"
          @click="toggleTask"
        >
          <span class="checkmark">✓</span>
        </button>
      </div>
    </div>

    <div class="task-card__body">
      <h3 class="task-title" :class="{ 'task-title--completed': task.completed }">
        {{ task.title }}
      </h3>
      <p class="task-text">{{ task.text }}</p>
    </div>

    <div class="task-card__footer">
      <div class="task-id">#{{ task.id }}</div>
      <div class="task-status">
        <span class="status-badge" :class="statusClass">
          {{ task.completed ? 'Выполнено' : 'В процессе' }}
        </span>
      </div>
    </div>

    <div class="task-progress" :class="progressClass"></div>
  </div>
</template>

<script>
export default {
  name: 'TaskItem',
  props: {
    task: {
      type: Object,
      required: true
    }
  },
  computed: {
    cardClasses() {
      return {
        'task-card--completed': this.task.completed,
        'task-card--high-priority': this.task.priority === 'high',
        'task-card--medium-priority': this.task.priority === 'medium',
        'task-card--low-priority': this.task.priority === 'low'
      }
    },
    priorityClass() {
      return `task-priority--${this.task.priority}`
    },
    priorityText() {
      const priorities = {
        high: 'Высокий',
        medium: 'Средний',
        low: 'Низкий'
      }
      return priorities[this.task.priority]
    },
    statusClass() {
      return this.task.completed ? 'status-badge--completed' : 'status-badge--pending'
    },
    progressClass() {
      return this.task.completed ? 'task-progress--completed' : ''
    }
  },
  methods: {
    toggleTask() {
      console.log(`Toggling task ${this.task.id}`)
    }
  }
}
</script>

<style scoped>
.task-card {
  background: white;
  border-radius: var(--radius);
  padding: 24px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.task-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 4px;
  height: 100%;
  background: var(--primary);
  transition: all 0.3s ease;
}

.task-card--high-priority::before {
  background: #ef4444;
}

.task-card--medium-priority::before {
  background: #f59e0b;
}

.task-card--low-priority::before {
  background: #10b981;
}

.task-card--completed::before {
  background: var(--accent);
}

.task-card:hover {
  box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.15);
  border-color: var(--primary);
}

.task-card--completed {
  opacity: 0.8;
  background: linear-gradient(135deg, #f8fafc, #f1f5f9);
}

.task-card__header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 16px;
}

.task-meta {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.task-category {
  background: var(--secondary);
  color: var(--text-secondary);
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  align-self: flex-start;
}

.task-priority {
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  align-self: flex-start;
}

.task-priority--high {
  background: #fef2f2;
  color: #dc2626;
  border: 1px solid #fecaca;
}

.task-priority--medium {
  background: #fffbeb;
  color: #d97706;
  border: 1px solid #fed7aa;
}

.task-priority--low {
  background: #f0fdf4;
  color: #059669;
  border: 1px solid #bbf7d0;
}

.task-actions {
  display: flex;
  gap: 8px;
}

.task-checkbox {
  width: 32px;
  height: 32px;
  border: 2px solid var(--border);
  border-radius: 50%;
  background: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  position: relative;
}

.task-checkbox:hover {
  border-color: var(--primary);
  transform: scale(1.1);
}

.task-checkbox--completed {
  background: var(--accent);
  border-color: var(--accent);
}

.task-checkbox--completed .checkmark {
  opacity: 1;
  transform: scale(1);
}

.checkmark {
  color: white;
  font-weight: bold;
  font-size: 14px;
  opacity: 0;
  transform: scale(0);
  transition: all 0.3s ease;
}

.task-card__body {
  flex: 1;
  margin-bottom: 20px;
}

.task-title {
  font-size: 1.25rem;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 12px;
  line-height: 1.4;
  transition: all 0.3s ease;
}

.task-title--completed {
  color: var(--text-secondary);
  text-decoration: line-through;
}

.task-text {
  color: var(--text-secondary);
  line-height: 1.6;
  font-size: 0.95rem;
}

.task-card__footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 16px;
  border-top: 1px solid var(--border);
}

.task-id {
  color: var(--text-secondary);
  font-size: 0.85rem;
  font-weight: 600;
}

.status-badge {
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.status-badge--pending {
  background: #eff6ff;
  color: #3b82f6;
  border: 1px solid #dbeafe;
}

.status-badge--completed {
  background: #f0fdf4;
  color: #059669;
  border: 1px solid #bbf7d0;
}

.task-progress {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  width: 0%;
  background: var(--primary);
  transition: width 0.3s ease;
}

.task-progress--completed {
  width: 100%;
  background: var(--accent);
}

.task-card--high-priority .task-progress {
  background: #ef4444;
}

.task-card--medium-priority .task-progress {
  background: #f59e0b;
}

.task-card--low-priority .task-progress {
  background: #10b981;
}

/* Анимации */
@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.task-card {
  animation: slideIn 0.5s ease forwards;
}

.task-card:nth-child(2) { animation-delay: 0.1s; }
.task-card:nth-child(3) { animation-delay: 0.2s; }
.task-card:nth-child(4) { animation-delay: 0.3s; }
.task-card:nth-child(5) { animation-delay: 0.4s; }
.task-card:nth-child(6) { animation-delay: 0.5s; }
</style>