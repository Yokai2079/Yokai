<template>
  <div id="app">
    <div class="app-container">
      <header class="app-header">
        <div class="header-content">
          <h1 class="app-title">
            <span class="title-icon">😐</span>
            MY TO-DO LIST
          </h1>
          <p class="app-subtitle">YoPR</p>
        </div>
      </header>

      <main class="main-content">
        <div class="tasks-stats">
          <div class="stat-card">
            <span class="stat-number">{{ tasks.length }}</span>
            <span class="stat-label">Total tasks</span>
          </div>
          <div class="stat-card">
            <span class="stat-number">{{ completedTasks }}</span>
            <span class="stat-label">Done</span>
          </div>
        </div>

        <div class="tasks-grid">
          <TaskItem 
            v-for="task in tasks" 
            :key="task.id" 
            :task="task"
            class="task-item"
          />
        </div>
      </main>

      <footer class="app-footer">
        <p>© 2025 CA-422K • Made by Andrew Yokai>< </p>
      </footer>
    </div>
  </div>
</template>

<script>
import TaskItem from './components/TaskItem.vue'

export default {
  name: 'App',
  components: {
    TaskItem
  },
  data() {
    return {
      tasks: [
        {
          id: 1,
          title: 'Сыграть 20ммов в доту',
          text: 'С болью',
          completed: true,
          priority: 'medium',
        },
        {
          id: 2,
          title: 'Попить кофе',
          text: 'В кофейне',
          completed: true,
          priority: 'low',
        },
        {
          id: 3,
          title: 'Поставить мне 5',
          text: 'А так же за все предыдущие работы',
          completed: false,
          priority: 'high',
        },
        {
          id: 4,
          title: 'Сходить в колледж',
          text: '(по желанию)',
          completed: true,
          priority: 'high',
        },
      ]
    }
  },
  computed: {
    completedTasks() {
      return this.tasks.filter(task => task.completed).length
    }
  }
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

:root {
  --primary: #6366f1;
  --primary-dark: #4f46e5;
  --secondary: #f8fafc;
  --accent: #06d6a0;
  --text-primary: #1e293b;
  --text-secondary: #64748b;
  --border: #e2e8f0;
  --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
  --radius: 16px;
}

body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: var(--text-primary);
  line-height: 1.6;
  min-height: 100vh;
}

#app {
  min-height: 100vh;
  padding: 20px;
}

.app-container {
  max-width: 1200px;
  margin: 0 auto;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  overflow: hidden;
  min-height: calc(100vh - 40px);
  display: flex;
  flex-direction: column;
}

.app-header {
  background: linear-gradient(135deg, var(--primary), var(--primary-dark));
  color: white;
  padding: 40px 0;
  text-align: center;
}

.header-content {
  max-width: 600px;
  margin: 0 auto;
  padding: 0 20px;
}

.app-title {
  font-size: 3rem;
  font-weight: 800;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
}

.title-icon {
  font-size: 2.5rem;
}

.app-subtitle {
  font-size: 1.2rem;
  opacity: 0.9;
  font-weight: 400;
}

.main-content {
  flex: 1;
  padding: 40px;
}

.tasks-stats {
  display: flex;
  gap: 20px;
  margin-bottom: 40px;
  justify-content: center;
}

.stat-card {
  background: white;
  padding: 24px;
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  text-align: center;
  min-width: 140px;
  border: 1px solid var(--border);
  transition: transform 0.2s ease;
}

.stat-card:hover {
  transform: translateY(-2px);
}

.stat-number {
  display: block;
  font-size: 2.5rem;
  font-weight: 800;
  color: var(--primary);
  line-height: 1;
}

.stat-label {
  font-size: 0.9rem;
  color: var(--text-secondary);
  font-weight: 500;
}

.tasks-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 24px;
}

.task-item {
  transition: all 0.3s ease;
}

.task-item:hover {
  transform: translateY(-4px);
}

.app-footer {
  background: var(--secondary);
  padding: 24px;
  text-align: center;
  border-top: 1px solid var(--border);
  color: var(--text-secondary);
  font-size: 0.9rem;
}

@media (max-width: 768px) {
  .app-title {
    font-size: 2.2rem;
  }
  
  .main-content {
    padding: 24px;
  }
  
  .tasks-stats {
    flex-direction: column;
    align-items: center;
  }
  
  .stat-card {
    width: 100%;
    max-width: 200px;
  }
  
  .tasks-grid {
    grid-template-columns: 1fr;
  }
  
  #app {
    padding: 10px;
  }
}

@media (max-width: 480px) {
  .app-title {
    font-size: 1.8rem;
    flex-direction: column;
    gap: 8px;
  }
  
  .main-content {
    padding: 16px;
  }
}
</style>